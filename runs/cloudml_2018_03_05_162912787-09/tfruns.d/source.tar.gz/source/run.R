install.packages('C://Users/Tianwei Zhang/Box Sync/2. Knowledge Development/Next product to buy/cloudml-master/cloudmlMcK_0.6.tar.gz')
remove.packages('cloudml')
devtools::install_github("rstudio/cloudml")
library(cloudml)
setwd('C:/Users/Tianwei Zhang/Box Sync/2. Knowledge Development/Next product to buy/google_cloud/')

## need to enable google prediction api in the dashboard
cloudml_train("train_script.R")
# gcloud_init()
# 
# remove.packages('cloudmlMcK')

setwd('C:/Users/Tianwei Zhang/Documents/R/win-library/3.4/cloudml/examples/mnist/')
cloudml_train(file = 'train.R',master_type = 'standard_gpu',config ='tuning.yml')
# job_collect("cloudml_2018_02_28_191913642")
# ls_runs()
# view_run()
# copy_run_files("cloudml_2018_02_28_191913642", to = "C:/gcloud/mnist_example")
job_status('cloudml_2018_02_28_193835198')
ls_runs()
cloudml_deploy("gs://easyai-196519/r-cloudml/runs/cloudml_2018_02_28_193835198/1/savedmodel/",name='minist_example',version = 'minist_example_3')
job_trials("cloudml_2018_02_28_193835198")


mnist_image <- keras::dataset_mnist()$train$x[1,,]
grid::grid.raster(mnist_image / 255)

cloudml_predict(
  list(
    as.vector(t(mnist_image))
  ),
  name = "minist_example",version = 'minist_example_1'
)
