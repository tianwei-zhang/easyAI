devtools::install_github("rstudio/cloudml")
library(cloudml)
gcloud_install()
